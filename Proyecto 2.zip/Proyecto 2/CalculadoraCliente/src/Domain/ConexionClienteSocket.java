/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 *
 * @author karla
 */
/**
 * Encapsula la comunicación de bajo nivel con el servidor desde el cliente.
 * IMPLEMENTA EL PROTOCOLO BINARIO (longitud + datos) para ser compatible
 * con el servidor.
 */
public class ConexionClienteSocket {

    private Socket socket;
    // ¡CAMBIO! Usamos los mismos tipos de stream que el servidor.
    private DataOutputStream out;
    private DataInputStream in;

    /**
     * Establece la conexión con el servidor.
     * @param host La dirección del servidor (ej: "localhost").
     * @param puerto El puerto en el que el servidor está escuchando.
     * @throws IOException Si la conexión falla.
     */
    public ConexionClienteSocket(String host, int puerto) throws IOException {
        this.socket = new Socket(host, puerto);
        // Es importante crear el OutputStream ANTES del InputStream para evitar problemas de bloqueo.
        this.out = new DataOutputStream(socket.getOutputStream());
        this.in = new DataInputStream(socket.getInputStream());
    }

    /**
     * Envía un mensaje de texto al servidor usando el protocolo binario.
     * Primero envía la longitud del mensaje como un entero, luego los bytes del mensaje.
     * @param mensaje El string XML a enviar.
     * @throws IOException Si ocurre un error de red.
     */
    public void enviarMensaje(String mensaje) throws IOException {
        byte[] mensajeBytes = mensaje.getBytes(StandardCharsets.UTF_8);
        out.writeInt(mensajeBytes.length); // Envía la longitud (entero de 4 bytes)
        out.write(mensajeBytes);           // Envía los bytes del mensaje
        out.flush();                       // ¡CRÍTICO! Asegura que los datos se envíen inmediatamente.
    }

    /**
     * Espera y recibe una respuesta del servidor que sigue el mismo protocolo binario.
     * @return El string XML recibido del servidor.
     * @throws IOException Si ocurre un error de red o el servidor cierra la conexión.
     */
    public String recibirRespuesta() throws IOException {
        int length = in.readInt(); // Lee la longitud del mensaje que viene
        if (length > 0) {
            byte[] mensajeBytes = new byte[length];
            in.readFully(mensajeBytes, 0, length); // Lee exactamente esa cantidad de bytes
            return new String(mensajeBytes, StandardCharsets.UTF_8);
        }
        return null;
    }

    /**
     * Cierra todos los recursos de la conexión de forma segura.
     */
    public void cerrar() {
        try { if (in != null) in.close(); } catch (IOException e) { /* ignorar */ }
        try { if (out != null) out.close(); } catch (IOException e) { /* ignorar */ }
        try { if (socket != null && !socket.isClosed()) socket.close(); } catch (IOException e) { /* ignorar */ }
    }
}
