/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import Common.Resultado;
import Common.Tarea;
import Common.TipoOperacion;
import Common.XMLUtility;
import Domain.ConexionClienteSocket;
import Domain.ControladorCliente;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

/**
 *
 * @author karla
 */
/**
 * Ventana de la GUI para que el usuario pueda consultar el estado de una tarea
 * previamente enviada, usando su ID.
 * Utiliza un SwingWorker para realizar la comunicación de red en un hilo de fondo
 * y evitar que la interfaz gráfica se congele.
 */
public class VentanaConsultaEstado extends JFrame {

    private String usuario;
    private ControladorCliente controlador;

    public VentanaConsultaEstado(String usuario, ControladorCliente controlador) {
        this.usuario = usuario;
        this.controlador = controlador;

        setTitle("Consultar Estado de Tarea");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // --- Componentes de la Interfaz Gráfica ---
        
        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel labelId = new JLabel("ID de la Tarea a Consultar:");
        JTextField txtIdTarea = new JTextField(10);
        JButton btnConsultar = new JButton("Consultar Estado");

        panelSuperior.add(labelId);
        panelSuperior.add(txtIdTarea);
        panelSuperior.add(btnConsultar);

        JTextArea txtResultados = new JTextArea();
        txtResultados.setEditable(false);
        txtResultados.setFont(new Font("Monospaced", Font.PLAIN, 14));
        txtResultados.setMargin(new Insets(10, 10, 10, 10));
        JScrollPane scroll = new JScrollPane(txtResultados);

        add(panelSuperior, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        // --- Lógica del Botón "Consultar" ---
        
        btnConsultar.addActionListener(e -> {
            String idAConsultar = txtIdTarea.getText().trim();

            if (idAConsultar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, ingrese un ID de tarea.", "Entrada Inválida", JOptionPane.ERROR_MESSAGE);
                return;
            }

            btnConsultar.setEnabled(false);
            txtResultados.setText("Consultando estado para la tarea ID " + idAConsultar + "...\nPor favor, espere.");

            // Usamos SwingWorker para no congelar la GUI
            SwingWorker<String, Void> worker = new SwingWorker<String, Void>() {

                @Override
                protected String doInBackground() throws Exception {
                    // --- Este código se ejecuta en un hilo de fondo ---
                    
                    // 1. Crear la Tarea de consulta
                    Tarea tareaDeConsulta = new Tarea();
                    
                    // ¡CORRECCIÓN! Usamos la variable 'usuario' de la clase externa
                    tareaDeConsulta.setIdCliente(usuario);
                    
                    tareaDeConsulta.setTipoOperacion(TipoOperacion.CONSULTA_ESTADO);
                    
                    Map<String, String> parametros = new HashMap<>();
                    parametros.put("idTarea", idAConsultar);
                    tareaDeConsulta.setParametros(parametros);
                    
                    String xmlConsulta = XMLUtility.toXML(tareaDeConsulta);

                    // Validamos que el XML se haya generado correctamente
                    if (xmlConsulta == null) {
                        throw new IOException("No se pudo generar el XML para la consulta. Tarea rechazada por XMLUtility.");
                    }

                    // 2. Realizar la comunicación de red
                    ConexionClienteSocket cliente = null;
                    try {
                        cliente = new ConexionClienteSocket("localhost", 9090);
                        cliente.enviarMensaje("<handshake><tipo>CLIENTE</tipo></handshake>");
                        cliente.enviarMensaje(xmlConsulta);
                        return cliente.recibirRespuesta();
                    } finally {
                        if (cliente != null) {
                            cliente.cerrar();
                        }
                    }
                }

                @Override
                protected void done() {
                    // --- Este código se ejecuta de vuelta en el hilo de la GUI ---
                    try {
                        // get() recupera el resultado de doInBackground()
                        String xmlRespuesta = get();
                        
                        Resultado resultado = XMLUtility.resultadoFromXML(xmlRespuesta);
                        
                        if (resultado != null) {
                            StringBuilder displayText = new StringBuilder();
                            displayText.append("Respuesta del Servidor para Tarea ID: ").append(idAConsultar).append("\n");
                            displayText.append("========================================\n\n");
                            
                            if (resultado.isExito()) {
                                // Si el mensaje indica que la tarea está completada, mostramos los datos.
                                if (resultado.getMensaje().toLowerCase().contains("unificado") || resultado.getMensaje().toLowerCase().contains("calculado")) {
                                    displayText.append("ESTADO:  Tarea Completada\n");
                                    displayText.append("MENSAJE: ").append(resultado.getMensaje()).append("\n");
                                    displayText.append("\n--> RESULTADO FINAL: ").append(resultado.getDatos()).append(" <--");
                                } else {
                                    // Si no, es un mensaje de estado intermedio.
                                    displayText.append("ESTADO:  En Proceso\n");
                                    displayText.append("MENSAJE: ").append(resultado.getMensaje()).append("\n");
                                }
                            } else {
                                // Si 'exito' es false, es un error del servidor.
                                displayText.append("ESTADO:  Error\n");
                                displayText.append("MENSAJE: ").append(resultado.getMensaje()).append("\n");
                            }
                            txtResultados.setText(displayText.toString());
                        } else {
                            txtResultados.setText("Error: No se pudo parsear la respuesta del servidor:\n" + xmlRespuesta);
                        }

                    } catch (Exception ex) {
                        // Captura errores que ocurrieron en doInBackground() (ej: error de conexión)
                        txtResultados.setText("Error durante la consulta: " + ex.getMessage());
                        ex.printStackTrace();
                    } finally {
                        // Volvemos a habilitar el botón, sin importar el resultado.
                        btnConsultar.setEnabled(true);
                    }
                }
            };

            worker.execute(); // Iniciar el SwingWorker
        });
    }
}
