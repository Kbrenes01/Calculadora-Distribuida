/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import Common.Resultado;
import Common.Tarea;
import java.util.List;

/**
 *
 * @author kbren
 */

//    /**
//     * Divide una tarea principal en una lista de subtareas más pequeñas.
//     * 
//     * @param tareaPrincipal La tarea original enviada por el cliente.
//     * @param numTrabajadoresDisponibles El número de trabajadores que pueden procesar las subtareas.
//     * @return Una lista de objetos Tarea, donde cada una representa una subtarea.
//     */
//    List<Tarea> dividir(Tarea tareaPrincipal, int numTrabajadoresDisponibles);
//
//    /**
//     * Unifica los resultados parciales de las subtareas para construir el resultado final.
//     * 
//     * @param tareaPrincipal La tarea original que inició el proceso.
//     * @param resultadosParciales Una lista de los resultados enviados por los trabajadores.
//     * @return Un objeto Resultado que contiene la respuesta final consolidada.
//     */
//    Tarea.Resultado unificar(Tarea tareaPrincipal, List<Tarea.Resultado> resultadosParciales);
//}
public interface IEstrategiaDistribucion {

    /**
     * Divide una tarea principal en subtareas para ser distribuidas.
     */
    List<Tarea> dividir(Tarea tareaPrincipal, int numTrabajadores);

    /**
     * Unifica los resultados parciales para generar un resultado final.
     */
    Resultado unificar(List<Resultado> resultadosParciales);
}