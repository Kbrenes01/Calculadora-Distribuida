/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import Common.TipoOperacion;
import static Common.TipoOperacion.BUSQUEDA_PRIMOS;
import static Common.TipoOperacion.DESCOMPOSICION_FACTORIAL;
import static Common.TipoOperacion.FACTORIAL;
import static Common.TipoOperacion.FIBONACCI;
import static Common.TipoOperacion.POTENCIA;
import static Common.TipoOperacion.PRODUCTO_MATRICES;

/**
 *
 * @author kbren
 */
/**
 * Fábrica (Patrón Factory) que crea la instancia de la estrategia de distribución
 * correcta para un tipo de operación dado.
 */
public class DistribucionFactory {

    public static IEstrategiaDistribucion getEstrategia(TipoOperacion tipo) {
        switch (tipo) {
            case BUSQUEDA_PRIMOS:
                return new EstrategiaBusquedaPrimos();
            
            case FACTORIAL:
                return new EstrategiaFactorial();
            
            // CORRECCIÓN: DESCOMPOSICION_FACTORIAL AHORA USA SU PROPIA ESTRATEGIA
            case DESCOMPOSICION_FACTORIAL:
                return new EstrategiaDescomposicionFactorial();

            // Estas son las únicas que (en este diseño) no se distribuyen
            case FIBONACCI:
                 return new EstrategiaFibonacciMatricial();
            case POTENCIA:
                return new EstrategiaNoDivisible();

            case PRODUCTO_MATRICES:
                return new EstrategiaMultiplicacionMatrices();
                
            default:
                throw new IllegalArgumentException("No hay una estrategia de distribución definida para: " + tipo);
        }
    }
}
