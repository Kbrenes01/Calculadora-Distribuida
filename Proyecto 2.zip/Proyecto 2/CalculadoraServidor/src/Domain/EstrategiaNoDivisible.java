/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import Common.Resultado;
import Common.Tarea;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author kbren
 */
public class EstrategiaNoDivisible implements IEstrategiaDistribucion {

    /**
     * Para operaciones no divisibles, la "división" consiste en devolver
     * la tarea original dentro de una lista con un solo elemento.
     */
    @Override
    public List<Tarea> dividir(Tarea tareaPrincipal, int numTrabajadores) {
        System.out.println("[EstrategiaNoDivisible] La operación " + tareaPrincipal.getTipoOperacion() + " no es divisible. Se enviará como una sola tarea.");
        return Collections.singletonList(tareaPrincipal);
    }

    /**
     * Si solo hay un resultado, la "unificación" consiste en devolver ese
     * único resultado sin modificarlo.
     */
    @Override
    public Resultado unificar(List<Resultado> resultadosParciales) {
        if (resultadosParciales != null && resultadosParciales.size() == 1) {
            System.out.println("[EstrategiaNoDivisible] Unificación simple completada.");
            return resultadosParciales.get(0);
        }
        // Devuelve un error si no se recibe exactamente un resultado.
        return new Resultado(false, "Error de unificación: se esperaba 1 resultado para tarea no divisible, pero se recibieron " + (resultadosParciales == null ? 0 : resultadosParciales.size()), null);
    }
}
