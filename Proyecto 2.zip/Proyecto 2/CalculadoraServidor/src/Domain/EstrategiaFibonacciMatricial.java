/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import Common.Resultado;
import Common.Tarea;
import Common.TipoOperacion;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author kbren
 */
public class EstrategiaFibonacciMatricial implements IEstrategiaDistribucion {

    @Override
    public List<Tarea> dividir(Tarea tareaPrincipal, int numTrabajadores) {
        int n = Integer.parseInt(tareaPrincipal.getParametros().get("limite"));
        if (numTrabajadores <= 1 || n < 2) {
            // Si no hay suficientes trabajadores o el cálculo es trivial, no se divide.
            return Collections.singletonList(tareaPrincipal);
        }

        List<Tarea> subtareas = new ArrayList<>();
        int exponentePorTrabajador = n / numTrabajadores;
        int exponenteRestante = n % numTrabajadores;

        for (int i = 0; i < numTrabajadores; i++) {
            int exponente = exponentePorTrabajador + (i == 0 ? exponenteRestante : 0);
            if (exponente == 0) continue;

            Map<String, String> params = new HashMap<>();
            params.put("exponente", String.valueOf(exponente));

            Tarea sub = new Tarea();
            sub.setId(tareaPrincipal.getId()); // Copia el ID de la tarea padre
            // ... (copiar IDs y tipo de operación de la tarea principal)
            sub.setTipoOperacion(TipoOperacion.FIBONACCI);
    sub.setParametros(params);
    sub.setEstado("PENDIENTE_DISTRIBUCION");

    subtareas.add(sub);
        }
        return subtareas;
    }

    @Override
    public Resultado unificar(List<Resultado> resultadosParciales) {
        // La unificación es una multiplicación de todas las matrices resultado.
        Matriz2x2 matrizFinal = new Matriz2x2(BigInteger.ONE, BigInteger.ZERO, BigInteger.ZERO, BigInteger.ONE); // Matriz identidad

        for (Resultado res : resultadosParciales) {
            if (res.isExito()) {
                // El trabajador devuelve la matriz resultado como "a,b,c,d"
                String[] valores = res.getDatos().split(",");
                Matriz2x2 matrizParcial = new Matriz2x2(
                    new BigInteger(valores[0]), new BigInteger(valores[1]),
                    new BigInteger(valores[2]), new BigInteger(valores[3])
                );
                matrizFinal = matrizFinal.multiplicar(matrizParcial);
            } else {
                return new Resultado(false, "Falló una subtarea de Fibonacci", null);
            }
        }
        
        // El resultado final fib(n) está en la posición 'b' de la matriz M^n
        return new Resultado(true, "Fibonacci (matricial) unificado con éxito.", matrizFinal.b.toString());
    }
}
