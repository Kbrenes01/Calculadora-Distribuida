/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import Common.Resultado;
import Common.Tarea;
import Common.TipoOperacion;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author kbren
 */
public class EstrategiaFactorial implements IEstrategiaDistribucion {

    @Override
    public List<Tarea> dividir(Tarea tareaPrincipal, int numTrabajadores) {
        List<Tarea> subtareas = new ArrayList<>();
        long n = Long.parseLong(tareaPrincipal.getParametros().get("numero"));

        if (numTrabajadores <= 0) numTrabajadores = 1;

        if (numTrabajadores == 1 || n < 4) {
            System.out.println("[EstrategiaFactorial] No se divide. Preparando tarea única para n=" + n);
            Map<String, String> paramsUnicaTarea = new HashMap<>();
            paramsUnicaTarea.put("rangoInicio", "1");
            paramsUnicaTarea.put("rangoFin", String.valueOf(n));
            tareaPrincipal.setParametros(paramsUnicaTarea);
            subtareas.add(tareaPrincipal);
            return subtareas;
        }

        long tamanoRango = n / numTrabajadores;
        long inicioRango = 1;

        System.out.println("[EstrategiaFactorial] Dividiendo " + n + "! en " + numTrabajadores + " subtareas.");

        for (int i = 0; i < numTrabajadores; i++) {
            long finRango = (i == numTrabajadores - 1) ? n : inicioRango + tamanoRango - 1;

            Map<String, String> paramsSubtarea = new HashMap<>();
            paramsSubtarea.put("rangoInicio", String.valueOf(inicioRango));
            paramsSubtarea.put("rangoFin", String.valueOf(finRango));

            Tarea sub = new Tarea();
            
            // ==========================================================
            // CORRECCIÓN APLICADA: Usar getId() y setId()
            // ==========================================================
            sub.setId(tareaPrincipal.getId()); // Hereda el ID de la tarea padre
            sub.setIdCliente(tareaPrincipal.getIdCliente());
            // ==========================================================
            
            sub.setTipoOperacion(TipoOperacion.FACTORIAL);
            sub.setParametros(paramsSubtarea);
            sub.setEstado("PENDIENTE_DISTRIBUCION");
            
            subtareas.add(sub);
            inicioRango = finRango + 1;
        }
        return subtareas;
    }

    @Override
    public Resultado unificar(List<Resultado> resultadosParciales) {
        if (resultadosParciales == null || resultadosParciales.isEmpty()) {
            return new Resultado(false, "No se recibieron resultados parciales para unificar.", null);
        }

        BigInteger resultadoFinal = BigInteger.ONE;
        for (Resultado res : resultadosParciales) {
            if (res.isExito() && res.getDatos() != null) {
                resultadoFinal = resultadoFinal.multiply(new BigInteger(res.getDatos()));
            } else {
                return new Resultado(false, "Una subtarea de Factorial falló: " + res.getMensaje(), null);
            }
        }
        
        System.out.println("[EstrategiaFactorial] Resultados parciales unificados con éxito.");
        return new Resultado(true, "Factorial calculado y unificado con éxito.", resultadoFinal.toString());
    }
}