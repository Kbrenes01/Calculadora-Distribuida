/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import Common.Resultado;
import Common.Tarea;
import Common.TipoOperacion;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author kbren
 */

/**
 * Estrategia de distribución para la descomposición factorial de un número grande.
 * La tarea se divide asignando a cada trabajador un sub-rango de posibles
 * divisores para probar.
 */
public class EstrategiaDescomposicionFactorial implements IEstrategiaDistribucion {

    @Override
    public List<Tarea> dividir(Tarea tareaPrincipal, int numTrabajadores) {
        List<Tarea> subtareas = new ArrayList<>();
        if (numTrabajadores <= 0) {
            numTrabajadores = 1; // Asegurar al menos un trabajador
        }

        BigInteger numeroAFactorizar = new BigInteger(tareaPrincipal.getParametros().get("numero"));
        
        // El límite superior para probar divisores es la raíz cuadrada del número.
        // BigInteger.sqrt() funciona en Java 9+. Si usas Java 8, necesitas una función de ayuda.
        BigInteger limiteSuperior = numeroAFactorizar.sqrt();

        // Convertimos a long. Si el número es astronómico, esto podría fallar.
        long rangoDeDivisores = limiteSuperior.longValue(); 

        // Si no vale la pena dividir, preparamos una única tarea.
        if (numTrabajadores == 1 || rangoDeDivisores < numTrabajadores) {
            Map<String, String> params = new HashMap<>();
            params.put("numero", numeroAFactorizar.toString());
            params.put("inicioDivisor", "2"); // El trabajador probará todos los divisores
            params.put("finDivisor", String.valueOf(rangoDeDivisores));
            tareaPrincipal.setParametros(params);
            subtareas.add(tareaPrincipal);
            return subtareas;
        }
        
        long tamanoSubrango = rangoDeDivisores / numTrabajadores;
        long inicioDivisor = 2; // Empezamos a probar divisores desde 2

        System.out.println("[EstrategiaDF] Dividiendo búsqueda de factores para " + numeroAFactorizar + " hasta divisor " + limiteSuperior);

        for (int i = 0; i < numTrabajadores; i++) {
            long finDivisor = (i == numTrabajadores - 1) ? rangoDeDivisores : inicioDivisor + tamanoSubrango - 1;

            Map<String, String> paramsSubtarea = new HashMap<>();
            paramsSubtarea.put("numero", numeroAFactorizar.toString());
            paramsSubtarea.put("inicioDivisor", String.valueOf(inicioDivisor));
            paramsSubtarea.put("finDivisor", String.valueOf(finDivisor));

            Tarea sub = new Tarea();
            sub.setId(tareaPrincipal.getId()); // Copia el ID de la tarea padre
            
            // ===============================================================
            //           ¡AQUÍ ESTÁ LA CORRECCIÓN DE CONSISTENCIA!
            // ===============================================================
            // Usamos setId() para coincidir con el resto del sistema.
            sub.setId(tareaPrincipal.getId());
            // ===============================================================
            
            sub.setIdCliente(tareaPrincipal.getIdCliente());
            sub.setTipoOperacion(TipoOperacion.DESCOMPOSICION_FACTORIAL);
            sub.setParametros(paramsSubtarea);
            sub.setEstado("PENDIENTE_DISTRIBUCION");
            
            subtareas.add(sub);
            inicioDivisor = finDivisor + 1;
        }
        return subtareas;
    }

 @Override
    public Resultado unificar(List<Resultado> resultadosParciales) {
        List<Long> factoresTotales = new ArrayList<>();
        
        for (Resultado res : resultadosParciales) {
            if (res.isExito() && res.getDatos() != null && !res.getDatos().equals("[]")) {
                String datosLimpios = res.getDatos().replace("[", "").replace("]", "").replace(" ", "");
                if (!datosLimpios.isEmpty()) {
                    Arrays.stream(datosLimpios.split(","))
                          .map(Long::parseLong)
                          .forEach(factoresTotales::add);
                }
            }
        }
        
        // ===============================================================
        //           ¡AQUÍ ESTÁ LA LÓGICA DE MENSAJE MEJORADA!
        // ===============================================================

        if (factoresTotales.isEmpty()) {
            // Caso 1: No se encontraron factores. El número es primo.
            String mensaje = "Descomposición completada. El número es primo.";
            System.out.println("[EstrategiaDF] Unificación completada. No se encontraron factores.");
            return new Resultado(true, mensaje, "El número es primo");
        
        } else {
            // Caso 2: Se encontraron factores. Los ordenamos y devolvemos.
            Collections.sort(factoresTotales);
            String resultadoFinal = factoresTotales.stream()
                                                   .map(String::valueOf)
                                                   .collect(Collectors.joining(", "));
            
            String mensaje = "Descomposición factorial completada.";
            System.out.println("[EstrategiaDF] Unificación completada. Factores encontrados: " + resultadoFinal);
            return new Resultado(true, mensaje, resultadoFinal);
        }
    }
}