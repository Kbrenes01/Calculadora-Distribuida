/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import Common.Tarea;
import Common.XMLUtility;
import Gestor.AlmacenCentral;
import java.io.PrintWriter;
import java.net.Socket;

/**
 *
 * @author kbren
 * 
 * Este será el cerebro que une las colas. Es un hilo que se ejecuta en segundo plano en el servidor. Su única misión es:
Esperar a que haya una tarea en colaDeTareasPendientes.
Esperar a que haya un trabajador en trabajadoresDisponibles.
Cuando ambos existan, saca la tarea y el trabajador, y le envía la tarea.
 */


public class DistribuidorDeTareas implements Runnable {

    @Override
    public void run() {
        System.out.println("[Distribuidor] Iniciado. Esperando tareas y trabajadores...");
        AlmacenCentral almacen = AlmacenCentral.getInstancia();

        while (true) {
            try {
                // 1. Espera bloqueante por una tarea y un trabajador
                Tarea tarea = almacen.obtenerTarea();
                Socket socketTrabajador = almacen.obtenerTrabajadorDisponible();

                System.out.println("[Distribuidor] Asignando Tarea ID " + tarea.getIdCliente()+ " a trabajador " + socketTrabajador.getInetAddress());

                // 2. Enviar la tarea al trabajador
                PrintWriter out = new PrintWriter(socketTrabajador.getOutputStream(), true);
                String xmlTarea = XMLUtility.toXML(tarea); // Usamos tu utilidad
                out.println(xmlTarea);
                
                // IMPORTANTE: Este diseño simple asume que el trabajador procesa la tarea y
                // la conexión con él se gestiona en otro hilo. Por ahora, esto funciona.

            } catch (InterruptedException e) {
                System.err.println("[Distribuidor] Hilo interrumpido. Saliendo.");
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                System.err.println("[Distribuidor] Error al enviar tarea: " + e.getMessage());
                // Aquí deberíamos manejar qué hacer con la tarea (¿re-encolarla?) y el trabajador (¿marcarlo como caído?).
            }
        }
    }
}

