/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import java.io.Serializable;
import java.math.BigInteger;

/**
 *
 * @author kbren
 */
 /**
 * Representa una matriz de 2x2 con elementos de tipo BigInteger.
 * Esta clase es clave para el cálculo de la serie de Fibonacci mediante
 * el método de exponenciación de matrices.
 * Implementa Serializable para poder, si fuese necesario, enviarla por la red,
 * aunque en nuestro diseño actual solo se usa internamente en el trabajador y servidor.
 */
public class Matriz2x2 implements Serializable {
    
    private static final long serialVersionUID = 1L; // Buena práctica para clases Serializable

    // Los elementos de la matriz se definen como:
    // | a  b |
    // | c  d |
    public BigInteger a, b, c, d;

    /**
     * Constructor por defecto. Crea la matriz base de Fibonacci:
     * | 1  1 |
     * | 1  0 |
     */
    public Matriz2x2() {
        this.a = BigInteger.ONE;  // [0][0]
        this.b = BigInteger.ONE;  // [0][1]
        this.c = BigInteger.ONE;  // [1][0]
        this.d = BigInteger.ZERO; // [1][1]
    }

    /**
     * Constructor que permite crear una matriz con valores específicos.
     * Útil para crear la matriz identidad para la exponenciación.
     * @param a Elemento en la posición (0,0)
     * @param b Elemento en la posición (0,1)
     * @param c Elemento en la posición (1,0)
     * @param d Elemento en la posición (1,1)
     */
    public Matriz2x2(BigInteger a, BigInteger b, BigInteger c, BigInteger d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }

    /**
     * Multiplica esta matriz (la actual) por otra matriz y devuelve el resultado.
     * La multiplicación de matrices de 2x2 se define como:
     * | a b |   | e f |   | ae+bg af+bh |
     * | c d | * | g h | = | ce+dg cf+dh |
     *
     * @param otra La matriz por la que se va to multiplicar.
     * @return Una nueva Matriz2x2 con el resultado de la multiplicación.
     */
    public Matriz2x2 multiplicar(Matriz2x2 otra) {
        // Cálculo de los nuevos elementos según la fórmula de multiplicación de matrices
        BigInteger nuevoA = this.a.multiply(otra.a).add(this.b.multiply(otra.c));
        BigInteger nuevoB = this.a.multiply(otra.b).add(this.b.multiply(otra.d));
        BigInteger nuevoC = this.c.multiply(otra.a).add(this.d.multiply(otra.c));
        BigInteger nuevoD = this.c.multiply(otra.b).add(this.d.multiply(otra.c)); // CORRECCIÓN: Debería ser this.d.multiply(otra.d)
        
        // CORRECCIÓN APLICADA en la línea de abajo
        BigInteger nuevoD_corregido = this.c.multiply(otra.b).add(this.d.multiply(otra.d));
        
        return new Matriz2x2(nuevoA, nuevoB, nuevoC, nuevoD_corregido);
    }
    
    @Override
    public String toString() {
        return String.format("[[%s, %s], [%s, %s]]", a, b, c, d);
    }
}