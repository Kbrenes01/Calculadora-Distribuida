/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import Common.Resultado;
import Common.Tarea;
import Common.TipoOperacion;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author kbren
 */
/**
 * Implementación de la estrategia de distribución para la búsqueda de números primos en un rango.
 */
public class EstrategiaBusquedaPrimos implements IEstrategiaDistribucion {

    @Override
public List<Tarea> dividir(Tarea tareaPrincipal, int numTrabajadores) {
    List<Tarea> subtareas = new ArrayList<>();
    if (numTrabajadores <= 0) numTrabajadores = 1;

    long inicioTotal = Long.parseLong(tareaPrincipal.getParametros().get("rangoInicio"));
    long finTotal = Long.parseLong(tareaPrincipal.getParametros().get("rangoFin"));
    long rangoTotal = finTotal - inicioTotal + 1;

    if (numTrabajadores == 1 || rangoTotal < numTrabajadores) {
        subtareas.add(tareaPrincipal);
        return subtareas;
    }

    // --- LÓGICA DE DIVISIÓN CORREGIDA ---
    
    long tamanoBloque = rangoTotal / numTrabajadores;
    long inicioActual = inicioTotal;

    for (int i = 0; i < numTrabajadores; i++) {
        long finActual = inicioActual + tamanoBloque - 1;

        // El último trabajador debe llegar hasta el final, por si la división no fue exacta.
        if (i == numTrabajadores - 1) {
            finActual = finTotal;
        }

        // Crear la subtarea con el rango [inicioActual, finActual]
        Map<String, String> paramsSubtarea = new HashMap<>();
        paramsSubtarea.put("rangoInicio", String.valueOf(inicioActual));
        paramsSubtarea.put("rangoFin", String.valueOf(finActual));

        Tarea sub = new Tarea();
        sub.setId(tareaPrincipal.getId());
        sub.setIdCliente(tareaPrincipal.getIdCliente());
        sub.setTipoOperacion(TipoOperacion.BUSQUEDA_PRIMOS);
        sub.setParametros(paramsSubtarea);
        sub.setEstado("PENDIENTE_DISTRIBUCION");
        
        subtareas.add(sub);

        // El inicio del siguiente bloque es el final de este + 1.
        inicioActual = finActual + 1;
        
        // Si ya hemos cubierto todo el rango, no creamos más tareas.
        if (inicioActual > finTotal) {
            break;
        }
    }
    return subtareas;
}

    @Override 
    public Resultado unificar(List<Resultado> resultadosParciales) {
        // Usamos una lista de Long para ordenar y evitar duplicados si fuera necesario.
        List<Long> todosLosPrimos = new ArrayList<>();
        
        for (Resultado parcial : resultadosParciales) {
            if (parcial.isExito() && parcial.getDatos() != null && !parcial.getDatos().isEmpty() && !parcial.getDatos().equals("[]")) {
                // El trabajador devuelve "[primo1, primo2]". Quitamos los corchetes.
                String datosLimpios = parcial.getDatos().replace("[", "").replace("]", "");
                if (!datosLimpios.trim().isEmpty()) {
                    // Convertimos el string "1, 2, 3" en una lista de Longs.
                    Arrays.stream(datosLimpios.split(","))
                          .map(s -> s.trim())
                          .map(Long::parseLong)
                          .forEach(todosLosPrimos::add);
                }
            }
        }
        
        // Ordenamos la lista de primos final.
        Collections.sort(todosLosPrimos);
        
        // Convertimos la lista ordenada de Longs a un solo String.
        String resultadoFinal = todosLosPrimos.stream()
                                               .map(String::valueOf)
                                               .collect(Collectors.joining(", "));
        
        String mensaje = "Se encontraron " + todosLosPrimos.size() + " números primos en total.";
        
        return new Resultado(true, mensaje, resultadoFinal);
    }
}