/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import Common.Tarea;
import Common.TipoOperacion;
import static Common.TipoOperacion.BUSQUEDA_PRIMOS;
import static Common.TipoOperacion.FACTORIAL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author kbren
 */
public class DivisorDeTareas {

    /**
     * Divide una tarea principal en una lista de subtareas.
     * @param tareaPrincipal La tarea original enviada por el cliente.
     * @param numTrabajadores El número de trabajadores disponibles.
     * @return Una lista de subtareas.
     * 
     */
    public List<Tarea> dividir(Tarea tareaPrincipal, int numTrabajadores) {
        List<Tarea> subtareas = new ArrayList<>();
        if (numTrabajadores <= 0) {
            // Si no hay trabajadores, no podemos dividir. Devolvemos la tarea original.
            subtareas.add(tareaPrincipal);
            return subtareas;
        }

        TipoOperacion tipo = tareaPrincipal.getTipoOperacion();
        Map<String, String> params = tareaPrincipal.getParametros();

        switch (tipo) {
            case BUSQUEDA_PRIMOS:
                // Lógica para dividir un rango de búsqueda de primos
                long inicio = Long.parseLong(params.get("rangoInicio"));
                long fin = Long.parseLong(params.get("rangoFin"));
                long rangoTotal = fin - inicio;
                long tamanoSubrango = rangoTotal / numTrabajadores;

                for (int i = 0; i < numTrabajadores; i++) {
                    long subInicio = inicio + (i * tamanoSubrango);
                    long subFin = (i == numTrabajadores - 1) ? fin : subInicio + tamanoSubrango - 1;
                    
                    // Aquí crearíamos una subtarea con este nuevo subrango
                    // Tarea sub = crearSubtarea(tareaPrincipal, subInicio, subFin);
                    // subtareas.add(sub);
                }
                break;

            case FACTORIAL:
                // La división para factorial es más compleja (división por rangos de producto)
                // Se implementaría aquí.
                break;
                
            // ... otros casos para cada tipo de operación
            
            default:
                // Si la operación no es divisible, se envía tal cual.
                subtareas.add(tareaPrincipal);
                break;
        }
        
        System.out.println("Tarea dividida en " + subtareas.size() + " subtareas.");
        return subtareas;
    }
    
    // Un método helper para crear subtareas podría ser útil
}
