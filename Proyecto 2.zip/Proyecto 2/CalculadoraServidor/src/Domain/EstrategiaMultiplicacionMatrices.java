/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import Common.Resultado;
import Common.Tarea;
import Common.TipoOperacion;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author kbren
 */
public class EstrategiaMultiplicacionMatrices implements IEstrategiaDistribucion {

    @Override
    public List<Tarea> dividir(Tarea tareaPrincipal, int numTrabajadores) {
        if (numTrabajadores <= 0) numTrabajadores = 1;

        // NOTA: Aquí asumimos que las matrices vienen como String en los parámetros.
        // Se necesita una forma robusta de parsearlas, pero para el ejemplo lo simplificamos.
        String matrizATexto = tareaPrincipal.getParametros().get("matrizA");
        String matrizBTexto = tareaPrincipal.getParametros().get("matrizB");
        
        // La lógica de parseo real puede ser más compleja.
        int numFilasA = matrizATexto.split("\n").length;
        
        List<Tarea> subtareas = new ArrayList<>();
        int filasPorTrabajador = numFilasA / numTrabajadores;
        int filaInicio = 0;

        for (int i = 0; i < numTrabajadores; i++) {
            int filasAsignadas = (i == numTrabajadores - 1) 
                ? numFilasA - filaInicio // El último trabajador toma las restantes
                : filasPorTrabajador;

            if (filasAsignadas == 0) continue;

            Tarea sub = new Tarea();
            sub.setId(tareaPrincipal.getId());
            sub.setIdCliente(tareaPrincipal.getIdCliente());
            sub.setTipoOperacion(TipoOperacion.PRODUCTO_MATRICES);
            sub.setEstado("PENDIENTE_DISTRIBUCION");

            Map<String, String> params = new HashMap<>();
            params.put("matrizA", matrizATexto); // Se envía la matriz A completa
            params.put("matrizB", matrizBTexto); // Se envía la matriz B completa
            params.put("fila_inicio", String.valueOf(filaInicio));
            params.put("filas_a_calcular", String.valueOf(filasAsignadas));
            sub.setParametros(params);
            
            subtareas.add(sub);
            filaInicio += filasAsignadas;
        }
        return subtareas;
    }

@Override
public Resultado unificar(List<Resultado> resultadosParciales) {
    Map<Integer, String> filasResultado = new TreeMap<>();

    for (Resultado res : resultadosParciales) {
        // --- ¡AQUÍ ESTÁ LA MEJORA! ---
        if (!res.isExito()) {
            // Si una subtarea falló, detenemos todo y devolvemos el mensaje de error
            // específico de esa subtarea para saber qué pasó en el trabajador.
            System.err.println("[EstrategiaMatrices] Una subtarea falló. Motivo: " + res.getMensaje());
            return new Resultado(false, "Una subtarea de multiplicación falló. Motivo: " + res.getMensaje(), null);
        }
        
        // El resto de la lógica de unificación si todo va bien...
        String[] partes = res.getDatos().split("\\|", 2);
        int filaInicio = Integer.parseInt(partes[0]);
        String datosFilas = partes[1];
        filasResultado.put(filaInicio, datosFilas);
    }

        // Reconstruimos la matriz final juntando las filas en orden.
        StringBuilder matrizFinalTexto = new StringBuilder();
        for (String bloqueFilas : filasResultado.values()) {
            matrizFinalTexto.append(bloqueFilas).append("\n");
        }
        
        return new Resultado(true, "Producto de matrices unificado con éxito.", matrizFinalTexto.toString().trim());
    }
}