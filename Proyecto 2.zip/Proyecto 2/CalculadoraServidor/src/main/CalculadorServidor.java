/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

import Data.ColaDeTareas;
import Domain.DistribuidorDeTareas;
import Gestor.DespachadorDeTareas;
import Gestor.GestorDeConexiones;
import Gestor.ManejadorDeConexion;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 *
 * @author kbren
 */
public class CalculadorServidor {

/**
 * Punto de entrada principal para la aplicación Servidor.
 * Su única función es crear e iniciar el GestorDeConexiones.
 */
    
 private static final int PUERTO = 9090;

    public static void main(String[] args) {
        System.out.println("Iniciando CalculadoraServidor...");

        // 1. Crear las colas compartidas
        ColaDeTareas colaDeTareas = ColaDeTareas.getInstancia();
        BlockingQueue<ManejadorDeConexion> trabajadoresDisponibles = new LinkedBlockingQueue<>();

        // 2. Crear e iniciar el Despachador en su propio hilo
        DespachadorDeTareas despachador = new DespachadorDeTareas(colaDeTareas, trabajadoresDisponibles);
        new Thread(despachador, "Despachador-Thread").start();

        // 3. Crear e iniciar el Gestor de Conexiones en el hilo principal
        //    (o en su propio hilo si el main necesita hacer más cosas)
        GestorDeConexiones gestor = new GestorDeConexiones(PUERTO, trabajadoresDisponibles);
        gestor.iniciar(); // Este método contiene el bucle infinito y bloqueará el main.
    }
}