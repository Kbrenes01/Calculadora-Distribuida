/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestor;

import Common.Resultado;
import Common.Tarea;
import Common.TipoOperacion;
import Common.XMLUtility;
import Data.ColaDeResultados;
import Data.ColaDeTareas;
import Domain.DistribucionFactory;
import Domain.IEstrategiaDistribucion;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;

/**
 *
 * @author kbren
 */
/**
 * Se ejecuta en un hilo separado para cada cliente/trabajador conectado.
 * Se encarga de leer las solicitudes (XML), procesarlas usando la capa de negocio,
 * y enviar las respuestas.
 */
public class ManejadorDeConexion implements Runnable {

    private final Socket socket;
    private final BlockingQueue<ManejadorDeConexion> trabajadoresDisponibles;
    private DataOutputStream out;

    public ManejadorDeConexion(Socket socket, BlockingQueue<ManejadorDeConexion> trabajadoresDisponibles) {
        this.socket = socket;
        this.trabajadoresDisponibles = trabajadoresDisponibles;
    }

    public Socket getSocket() {
        return this.socket;
    }
    
    public void enviarTareaATrabajador(Tarea tarea) throws IOException {
        String xmlTarea = XMLUtility.toXML(tarea);
        if (this.out != null) {
            enviarMensaje(this.out, xmlTarea);
        }
    }

    @Override
    public void run() {
        DataInputStream in = null;
        boolean esTrabajador = false;

        try {
            in = new DataInputStream(socket.getInputStream());
            this.out = new DataOutputStream(socket.getOutputStream());

            String primerMensaje = recibirMensaje(in);
            if (primerMensaje == null) {
                System.out.println("[Servidor] Conexión cerrada antes del handshake.");
                return;
            }

            if (primerMensaje.contains("<tipo>CLIENTE</tipo>")) {
                System.out.println("[Servidor] Cliente conectado desde: " + socket.getInetAddress().getHostAddress());
                manejarCliente(in, this.out);
            } else if (primerMensaje.contains("<tipo>TRABAJADOR</tipo>")) {
                esTrabajador = true;
                trabajadoresDisponibles.put(this);
                System.out.println("[Servidor] Trabajador " + socket.getInetAddress() + " añadido a la cola. Disponibles: " + trabajadoresDisponibles.size());
                manejarTrabajador(in, this.out);
            }

        } catch (IOException | InterruptedException e) {
            System.err.println("[Servidor] Error de IO o interrupción en la conexión, cerrando hilo: " + e.getMessage());
        } finally {
            if (esTrabajador) {
                trabajadoresDisponibles.remove(this);
                System.out.println("[Servidor] Trabajador desconectado. Removido de la cola. Restantes: " + trabajadoresDisponibles.size());
            }

            try {
                if (socket != null && !socket.isClosed()) {
                    socket.close();
                }
            } catch (IOException ignored) {}
            
            System.out.println("[Servidor] Conexión con " + socket.getInetAddress().getHostAddress() + " finalizada.");
        }
    }

    private void enviarMensaje(DataOutputStream out, String mensaje) throws IOException {
        byte[] mensajeBytes = mensaje.getBytes(StandardCharsets.UTF_8);
        out.writeInt(mensajeBytes.length);
        out.write(mensajeBytes);
        out.flush();
    }
    
    private String recibirMensaje(DataInputStream in) throws IOException {
        try {
            int length = in.readInt();
            if (length > 0) {
                byte[] mensajeBytes = new byte[length];
                in.readFully(mensajeBytes, 0, length);
                return new String(mensajeBytes, StandardCharsets.UTF_8);
            }
            return null;
        } catch (EOFException e) {
            return null; // El stream se cerró limpiamente.
        }
    }

    private void manejarCliente(DataInputStream in, DataOutputStream out) {
        try {
            String xmlRecibido;
            while ((xmlRecibido = recibirMensaje(in)) != null) {
                System.out.println("[Cliente] XML recibido:\n" + xmlRecibido);
                
                Tarea tareaPrincipal = XMLUtility.fromXML(xmlRecibido);
                Resultado resultadoParaEnviar;

                if (tareaPrincipal == null) {
                    resultadoParaEnviar = new Resultado(false, "Error: El formato del XML recibido es inválido.", null);
                } else {
                    if (tareaPrincipal.getTipoOperacion() == TipoOperacion.CONSULTA_ESTADO) {
                        resultadoParaEnviar = consultarEstado(tareaPrincipal);
                    } else {
                        try {
                            ColaDeTareas cola = ColaDeTareas.getInstancia();
                            int idTarea = cola.asignarSiguienteId();
                            tareaPrincipal.setId(idTarea);
                            tareaPrincipal.setEstado("RECIBIDA");

                            IEstrategiaDistribucion estrategia = DistribucionFactory.getEstrategia(tareaPrincipal.getTipoOperacion());
                            List<Tarea> subtareas = estrategia.dividir(tareaPrincipal, trabajadoresDisponibles.size());
                            
                            System.out.println("[Servidor] Tarea " + idTarea + " dividida en " + subtareas.size() + " subtareas.");

                            if (!subtareas.isEmpty()) {
                                ColaDeResultados.getInstancia().registrarTareaParaUnificacion(tareaPrincipal, subtareas.size());
                            }

                            for (Tarea sub : subtareas) {
                                cola.agregarTarea(sub);
                            }

                            System.out.println("[Servidor] Tarea de tipo '" + tareaPrincipal.getTipoOperacion() + "' encolada con ID: " + idTarea);
                            resultadoParaEnviar = new Resultado(true, "Tarea recibida y encolada correctamente.", String.valueOf(idTarea));

                        } catch (Exception e) {
                            resultadoParaEnviar = new Resultado(false, "Error interno del servidor al procesar la solicitud.", null);
                            e.printStackTrace();
                        }
                    }
                }

                String xmlRespuesta = XMLUtility.toXML(resultadoParaEnviar);
    if (xmlRespuesta == null) {
                    System.err.println("[Servidor] Error crítico: XMLUtility devolvió una cadena nula para el resultado. Esto indica un problema en la serialización. Enviando error genérico.");
                    
                    // Creamos un resultado de error seguro que no fallará al serializar.
                    Resultado errorInterno = new Resultado(false, "Error interno del servidor al generar la respuesta XML (posiblemente en XMLUtility).", null);
                    xmlRespuesta = XMLUtility.toXML(errorInterno);
                }
                // ===============================================================

                enviarMensaje(out, xmlRespuesta);
                System.out.println("[Servidor] XML de respuesta enviado al cliente:\n" + xmlRespuesta);
            }
        } catch (EOFException e) {
            System.out.println("[Servidor] El cliente cerró la conexión limpiamente.");
        } catch (IOException e) {
            System.err.println("[Cliente] Error en el manejo de la conexión del cliente: " + e.getMessage());
        }
    }

    private Resultado consultarEstado(Tarea tareaConsulta) {
        ColaDeTareas cola = ColaDeTareas.getInstancia();
        Map<String, String> params = tareaConsulta.getParametros();

        if (params == null || !params.containsKey("idTarea")) {
            return new Resultado(false, "Para consultar estado, debe especificar un 'idTarea' en los parámetros.", null);
        }
        
        try {
            int id = Integer.parseInt(params.get("idTarea"));
            Tarea tareaEnCola = cola.getTareaPorId(id);

            if (tareaEnCola != null) {
                if ("COMPLETADA".equals(tareaEnCola.getEstado()) && tareaEnCola.getResultado() != null) {
                    System.out.println("[Consulta] Devolviendo resultado final para Tarea ID " + id);
                    return tareaEnCola.getResultado(); 
                } else {
                    System.out.println("[Consulta] Tarea ID " + id + " aún en proceso. Estado: " + tareaEnCola.getEstado());
                    return new Resultado(true, "La tarea con ID " + id + " sigue en proceso. Estado actual: " + tareaEnCola.getEstado(), tareaEnCola.getEstado());
                }
            } else {
                return new Resultado(false, "No se encontró una tarea con el ID " + id, null);
            }
        } catch (NumberFormatException e) {
            return new Resultado(false, "El idTarea proporcionado no es un número válido.", null);
        }
    }

    private void manejarTrabajador(DataInputStream in, DataOutputStream out) {
        System.out.println("[Trabajador " + socket.getInetAddress() + "] Hilo dedicado iniciado. Esperando resultados...");
        try {
            while (!socket.isClosed() && socket.isConnected()) {
                String xmlResultado = recibirMensaje(in);
                if (xmlResultado == null) break;

                System.out.println("[Trabajador " + socket.getInetAddress() + "] Resultado XML recibido.");
                Tarea tareaCompletada = XMLUtility.fromXML(xmlResultado);

                if (tareaCompletada != null && tareaCompletada.getId() != 0 && tareaCompletada.getResultado() != null) {
                    ColaDeResultados.getInstancia().encolarResultado(tareaCompletada);
                    
                    // El trabajador ha terminado su ciclo de trabajo. Se vuelve a poner disponible.
                    trabajadoresDisponibles.put(this);
                    System.out.println("[Servidor] Trabajador " + socket.getInetAddress() + " ha terminado y vuelve a estar disponible. Total disponibles: " + trabajadoresDisponibles.size());
                } else {
                    System.err.println("[Trabajador] Error: Tarea recibida del trabajador es nula, inválida, no tiene ID o no contiene resultado.");
                }
            }
        } catch (EOFException e) {
            System.out.println("[Trabajador " + socket.getInetAddress() + "] cerró la conexión limpiamente.");
        } catch (IOException | InterruptedException e) {
            System.err.println("[Trabajador " + socket.getInetAddress() + "] Error de comunicación o interrupción: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("[Trabajador " + socket.getInetAddress() + "] Error inesperado al procesar resultado: " + e.getMessage());
            e.printStackTrace();
        } finally {
            System.out.println("[Trabajador " + socket.getInetAddress() + "] Hilo de manejo finalizado.");
        }
    }
}