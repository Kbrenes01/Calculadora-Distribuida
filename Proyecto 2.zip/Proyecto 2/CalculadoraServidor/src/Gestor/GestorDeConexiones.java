/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.BlockingQueue;

/**
 *
 * @author kbren
 */
/**
 * Clase principal de la capa de comunicación del servidor.
 * Su única responsabilidad es escuchar en un puerto y aceptar conexiones entrantes.
 * Por cada conexión, crea un hilo 'ManejadorDeConexion' para atenderla,
 * pasándole la cola de trabajadores disponibles.
 */
public class GestorDeConexiones {

    private final int puerto;
    // ¡CAMBIO! Ahora recibe la cola de trabajadores, no la crea.
    private final BlockingQueue<ManejadorDeConexion> trabajadoresDisponibles;

    /**
     * Constructor del Gestor de Conexiones.
     * @param puerto El puerto en el que escuchará el servidor.
     * @param trabajadoresDisponibles La cola compartida donde los trabajadores se registrarán.
     */
    public GestorDeConexiones(int puerto, BlockingQueue<ManejadorDeConexion> trabajadoresDisponibles) {
        this.puerto = puerto;
        this.trabajadoresDisponibles = trabajadoresDisponibles;
    }

    /**
     * Inicia el bucle infinito para aceptar nuevas conexiones.
     * Este método es bloqueante y debe ejecutarse en su propio hilo.
     */
    public void iniciar() {
        System.out.println("Servidor escuchando en el puerto " + puerto + "...");
        
        try (ServerSocket serverSocket = new ServerSocket(puerto)) {
            // El bucle se ejecuta para siempre, aceptando una conexión tras otra.
            while (true) {
                // El método accept() se queda "bloqueado" hasta que un cliente o trabajador se conecta.
                Socket nuevoSocket = serverSocket.accept();
                System.out.println("-> Nueva conexión entrante desde: " + nuevoSocket.getInetAddress().getHostAddress());
                
                // Creamos un nuevo objeto para manejar esta conexión específica.
                // ¡CAMBIO! Le pasamos la cola de trabajadores al manejador.
                ManejadorDeConexion manejador = new ManejadorDeConexion(nuevoSocket, trabajadoresDisponibles);
                
                // Iniciamos el manejador en un nuevo hilo para no bloquear el bucle principal.
                // Esto permite al servidor atender a MUCHOS clientes y trabajadores a la vez.
                new Thread(manejador, "Manejador-" + nuevoSocket.getPort()).start();
            }
        } catch (IOException e) {
            System.err.println("Error crítico en el Gestor de Conexiones (Puerto " + puerto + "): " + e.getMessage());
            e.printStackTrace();
        }
    }
}