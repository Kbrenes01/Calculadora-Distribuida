/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestor;

import Common.Tarea;
import Data.ColaDeTareas;
import Gestor.ManejadorDeConexion;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author karla
 */
/**
 * Hilo de fondo cuya única responsabilidad es monitorear la cola de tareas
 * y la cola de trabajadores disponibles. Cuando hay una tarea y un trabajador,
 * los empareja y despacha la tarea.
 */
public class DespachadorDeTareas implements Runnable {
    
    private final ColaDeTareas colaDeTareas;
    private final BlockingQueue<ManejadorDeConexion> trabajadoresDisponibles;

    /**
     * Constructor del Despachador.
     * @param cola La cola de tareas de donde se sacarán los trabajos.
     * @param trabajadores La cola de trabajadores disponibles.
     */
    public DespachadorDeTareas(ColaDeTareas cola, BlockingQueue<ManejadorDeConexion> trabajadores) {
        this.colaDeTareas = cola;
        this.trabajadoresDisponibles = trabajadores;
    }

    /**
     * El bucle principal del despachador. Se ejecuta indefinidamente.
     */
    @Override
    public void run() {
        System.out.println("[Despachador] Iniciado. Monitoreando colas...");
        
        // Bucle infinito para estar siempre despachando.
        while (true) {
            try {
                // 1. Tomar una tarea de la cola.
                //    El método take() se bloqueará de forma segura si la cola está vacía,
                //    sin consumir CPU, hasta que una tarea esté disponible.
                Tarea tareaADespachar = colaDeTareas.tomarTarea(); 
                
                System.out.println("[Despachador] Tarea " + tareaADespachar.getId() + " lista. Esperando por un trabajador disponible...");
                
                // 2. Tomar un trabajador de la cola.
                //    Igualmente, take() se bloqueará de forma segura hasta que un
                //    trabajador se ponga a sí mismo en la cola de disponibles.
                ManejadorDeConexion trabajadorAsignado = trabajadoresDisponibles.take();
                
                System.out.println("[Despachador] Trabajador " + trabajadorAsignado.getSocket().getInetAddress() + " asignado. Despachando tarea " + tareaADespachar.getId());
                
                // 3. Enviar la tarea al trabajador.
                //    El Despachador NO espera la respuesta. Su trabajo termina aquí.
                //    El hilo del ManejadorDeConexion de ese trabajador se encargará
                //    de recibir el resultado y ponerse de nuevo en la cola.
                trabajadorAsignado.enviarTareaATrabajador(tareaADespachar);

            } catch (InterruptedException e) {
                // Esta excepción se lanza si el hilo del despachador es interrumpido.
                // Es la forma correcta de detener el bucle.
                System.err.println("[Despachador] Hilo interrumpido. Finalizando despacho de tareas.");
                Thread.currentThread().interrupt(); // Buena práctica para preservar el estado de interrupción.
                break; // Salir del bucle while.
            } catch (IOException e) {
                // Esto podría pasar si el socket del trabajador se cierra justo cuando
                // intentamos enviarle la tarea.
                System.err.println("[Despachador] Error de red al enviar tarea. La tarea podría haberse perdido.");
                // Nota: un sistema más robusto volvería a encolar la tarea.
                e.printStackTrace();
            } catch (Exception e) {
                // Captura cualquier otro error inesperado para que el despachador no muera.
                System.err.println("[Despachador] Error inesperado durante el despacho.");
                e.printStackTrace();
            }
        }
    }
}