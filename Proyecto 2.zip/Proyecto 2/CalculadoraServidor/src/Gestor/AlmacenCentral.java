/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestor;

import Common.Resultado;
import Common.Tarea;
import java.net.Socket;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

/**
 *
 * @author kbren
 */
//AlmacenCentral.java, que será un Singleton (Patrón de Diseño #1). Esto asegura que solo haya una instancia.
//de este almacén en todo el servidor.
public class AlmacenCentral {

    private static final AlmacenCentral instancia = new AlmacenCentral();

    // Cola de tareas pendientes que los clientes envían. Es thread-safe.
    private final BlockingQueue<Tarea> colaDeTareasPendientes = new LinkedBlockingQueue<>();
    
    // Mapa para guardar los resultados. La clave es el ID de la tarea.
    private final ConcurrentHashMap<String, Resultado> mapaDeResultados = new ConcurrentHashMap<>();

    // Lista de trabajadores conectados y listos para recibir trabajo.
    private final BlockingQueue<Socket> trabajadoresDisponibles = new LinkedBlockingQueue<>();
    
    private AlmacenCentral() {}

    public static AlmacenCentral getInstancia() {
        return instancia;
    }

    // --- Métodos para Tareas ---
    public void agregarTarea(Tarea tarea) {
        // Asignamos un ID único a la tarea antes de encolarla
        tarea.setIdCliente(UUID.randomUUID().toString()); // ¡Importante! Necesitas un ID para la tarea
        tarea.setEstado("PENDIENTE");
        colaDeTareasPendientes.add(tarea);
        System.out.println("[Almacen] Nueva tarea encolada. ID: " + tarea.getIdCliente());
    }
    
    public Tarea obtenerTarea() throws InterruptedException {
        // take() bloquea el hilo hasta que haya una tarea disponible.
        return colaDeTareasPendientes.take();
    }
    
    public void guardarResultado(String idTarea, Resultado resultado) {
        mapaDeResultados.put(idTarea, resultado);
        System.out.println("[Almacen] Resultado guardado para la tarea ID: " + idTarea);
    }

    public Resultado obtenerResultado(String idTarea) {
        return mapaDeResultados.get(idTarea);
    }

    // --- Métodos para Trabajadores ---
    public void agregarTrabajador(Socket socketTrabajador) {
        trabajadoresDisponibles.add(socketTrabajador);
        System.out.println("[Almacen] Nuevo trabajador disponible. Total: " + trabajadoresDisponibles.size());
    }
    
    public Socket obtenerTrabajadorDisponible() throws InterruptedException {
        // take() bloquea hasta que un trabajador esté disponible.
        return trabajadoresDisponibles.take();
    }
    
    public int getNumeroDeTrabajadoresDisponibles() {
    return trabajadoresDisponibles.size();
}
    public void removerTrabajador(Socket socketTrabajador) {
        boolean removido = trabajadoresDisponibles.remove(socketTrabajador);
        if (removido) {
            System.out.println("[Almacen] Trabajador " + socketTrabajador.getInetAddress() + " removido de la lista de disponibles.");
        }
    }
}
