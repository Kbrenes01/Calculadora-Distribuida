/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Data;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author kbren
 */
/**
 * Clase de utilidad para manejar la escritura de datos XML en el disco duro del servidor.
 */
public class GestorPersistencia {

    // Definimos una carpeta donde se guardarán todos los datos
    private static final String CARPETA_DATOS = "server_data";

    /**
     * Guarda una cadena XML en un archivo especificado.
     * @param nombreArchivo El nombre del archivo (ej: "tareas.xml").
     * @param contenidoXML El String que contiene los datos XML.
     */
    public static synchronized void guardarEnArchivo(String nombreArchivo, String contenidoXML) {
        try {
            // 1. Asegurarse de que la carpeta de datos exista
            File carpeta = new File(CARPETA_DATOS);
            if (!carpeta.exists()) {
                if (carpeta.mkdir()) {
                    System.out.println("[Persistencia] Carpeta de datos creada: " + carpeta.getAbsolutePath());
                }
            }
            
            // 2. Crear el archivo dentro de la carpeta
            File archivo = new File(carpeta, nombreArchivo);

            // 3. Escribir el contenido XML en el archivo
            try (FileWriter writer = new FileWriter(archivo)) {
                writer.write(contenidoXML);
            }
            
            System.out.println("[Persistencia] Datos guardados con éxito en: " + archivo.getAbsolutePath());

        } catch (IOException e) {
            System.err.println("[Persistencia] Error al guardar datos en el archivo " + nombreArchivo + ": " + e.getMessage());
            e.printStackTrace();
        }
    }
}
