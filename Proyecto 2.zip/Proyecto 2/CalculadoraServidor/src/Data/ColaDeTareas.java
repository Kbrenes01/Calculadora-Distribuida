/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Data;

import Common.Tarea;
import Common.XMLUtility;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author kbren
 */


/**
 * Almacén central para las tareas. Administra la cola de trabajo pendiente,
 * un mapa para acceso rápido por ID, y se encarga de persistir el estado
 * del sistema en un archivo XML.
 * Es un Singleton para garantizar un único punto de control.
 */
public class ColaDeTareas {

    // --- Singleton Pattern ---
    private static final ColaDeTareas instancia = new ColaDeTareas();

    // --- Atributos de la clase ---
    private final BlockingQueue<Tarea> tareasPendientes;
    private final ConcurrentHashMap<Integer, Tarea> mapaDeTareas;
    private final AtomicInteger generadorDeId;

    // --- Constructor ---
    private ColaDeTareas() {
        this.tareasPendientes = new LinkedBlockingQueue<>();
        this.mapaDeTareas = new ConcurrentHashMap<>();
        this.generadorDeId = new AtomicInteger(1);
    }

    public static ColaDeTareas getInstancia() {
        return instancia;
    }

    public int asignarSiguienteId() {
        return generadorDeId.getAndIncrement();
    }
    
    // --- Métodos Principales ---

    /**
     * Agrega una tarea (o subtarea) al sistema.
     * La añade al mapa, a la cola y dispara la persistencia.
     */
    public void agregarTarea(Tarea tarea) {
        if (tarea.getId() == 0) {
            System.err.println("ADVERTENCIA: Se encoló una tarea sin ID asignado.");
            return;
        }
        
        mapaDeTareas.put(tarea.getId(), tarea); // Actualiza o añade la tarea en el mapa
        
        try {
            tareasPendientes.put(tarea);
            System.out.println("[ColaDeTareas] Tarea (o subtarea) con ID " + tarea.getId() + " añadida a la cola. Pendientes: " + tareasPendientes.size());
            
            // ¡PERSISTENCIA! Guardamos el estado actual del sistema en disco.
            persistirTodasLasTareas();

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Error: El hilo fue interrumpido mientras esperaba para encolar la tarea " + tarea.getId());
        }
    }

    /**
     * Actualiza una tarea existente en el mapa.
     * Es llamado por ColaDeResultados cuando una tarea se completa.
     * También dispara la persistencia.
     */
    public void actualizarTarea(int idTarea, Tarea tareaActualizada) {
        mapaDeTareas.put(idTarea, tareaActualizada);
        System.out.println("[ColaDeTareas] Tarea " + idTarea + " ha sido actualizada en el mapa.");
        
        // ¡PERSISTENCIA! Guardamos el estado actual del sistema en disco.
        persistirTodasLasTareas();
    }

    /**
     * Busca y devuelve una tarea por su ID desde el mapa.
     */
    public Tarea getTareaPorId(int idTarea) {
        return mapaDeTareas.get(idTarea);
    }
    
    /**
     * Método para que el Despachador tome tareas de la cola.
     */
    public Tarea tomarTarea() throws InterruptedException {
        Tarea tarea = tareasPendientes.take();
        System.out.println("[ColaDeTareas] Tarea con ID " + tarea.getId() + " tomada por el despachador.");
        return tarea;
    }
    
    // ===============================================================
    //      NUEVO MÉTODO PRIVADO PARA MANEJAR LA PERSISTENCIA
    // ===============================================================
    /**
     * Genera un único String XML con el estado de todas las tareas
     * actualmente en el sistema y lo guarda en un archivo.
     */
    private void persistirTodasLasTareas() {
        // Creamos un elemento raíz para nuestro archivo XML.
        StringBuilder xmlCompleto = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<SistemaTareas>\n");
        
        // Iteramos sobre todos los valores (objetos Tarea) del mapa.
        for (Tarea tarea : mapaDeTareas.values()) {
            String xmlTareaIndividual = XMLUtility.toXML(tarea);
            if (xmlTareaIndividual != null) {
                // Añadimos el XML de cada tarea.
                xmlCompleto.append(xmlTareaIndividual).append("\n");
            }
        }
        
        xmlCompleto.append("</SistemaTareas>");
        
        // Llamamos a nuestro gestor para que guarde el string en el archivo.
        GestorPersistencia.guardarEnArchivo("estado_sistema_tareas.xml", xmlCompleto.toString());
    }
}