/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Data;

import Common.Resultado;
import Common.Tarea;
import Domain.DistribucionFactory;
import Domain.IEstrategiaDistribucion;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author kbren
 */
/**
 * Administra la recepción y unificación de los resultados enviados por los trabajadores.
 * Actúa como la "Cola de Respuestas" del sistema, como se especifica en el enunciado.
 * Es un Singleton para garantizar un único punto de control.
 */
public class ColaDeResultados {

    // --- Singleton Pattern ---
    private static final ColaDeResultados instancia = new ColaDeResultados();

    /**
     * Mapa que lleva la cuenta de cuántos resultados faltan para cada tarea principal.
     * Clave: ID de la Tarea. Valor: Contador atómico.
     */
    private final ConcurrentHashMap<Integer, AtomicInteger> contadoresSubtareas;
    
    /**
     * Almacén temporal para los resultados parciales que van llegando.
     * Clave: ID de la Tarea. Valor: Lista sincronizada de resultados.
     */
    private final ConcurrentHashMap<Integer, List<Resultado>> resultadosParciales;
    
    /**
     * Guarda una copia de la tarea original para saber su tipo al momento de unificar.
     * Clave: ID de la Tarea. Valor: Objeto Tarea original.
     */
    private final ConcurrentHashMap<Integer, Tarea> tareasOriginales;

    /**
     * Constructor privado del Singleton.
     */
    private ColaDeResultados() {
        this.contadoresSubtareas = new ConcurrentHashMap<>();
        this.resultadosParciales = new ConcurrentHashMap<>();
        this.tareasOriginales = new ConcurrentHashMap<>();
    }

    /**
     * Método para obtener la única instancia de la clase.
     * @return La instancia Singleton de ColaDeResultados.
     */
    public static ColaDeResultados getInstancia() {
        return instancia;
    }

    /**
     * Prepara la cola para recibir los resultados de una nueva tarea que ha sido dividida.
     * Se debe llamar a este método desde el servidor justo después de dividir una tarea.
     * @param tareaPrincipal La tarea original del cliente, que ya tiene su ID asignado.
     * @param numeroDeSubtareas El número de partes en que se dividió la tarea.
     */
    public void registrarTareaParaUnificacion(Tarea tareaPrincipal, int numeroDeSubtareas) {
        int idTarea = tareaPrincipal.getId();
        if (numeroDeSubtareas <= 0) {
            System.err.println("[ColaDeResultados] Advertencia: Se intentó registrar una tarea con 0 subtareas (ID: " + idTarea + ").");
            return;
        }

        contadoresSubtareas.put(idTarea, new AtomicInteger(numeroDeSubtareas));
        resultadosParciales.put(idTarea, Collections.synchronizedList(new ArrayList<>()));
        tareasOriginales.put(idTarea, tareaPrincipal);
        System.out.println("[ColaDeResultados] Tarea " + idTarea + " registrada. Esperando " + numeroDeSubtareas + " resultados.");
    }

    /**
     * Procesa un resultado que llega de un trabajador.
     * Lo almacena y, si es el último resultado que faltaba para una tarea,
     * dispara el proceso de unificación.
     * @param tareaConResultado La tarea completa que devuelve el trabajador.
     */
    public void encolarResultado(Tarea tareaConResultado) {
        int idTarea = tareaConResultado.getId();
        Resultado resultadoParcial = tareaConResultado.getResultado();

        if (!contadoresSubtareas.containsKey(idTarea)) {
            System.err.println("[ColaDeResultados] Se recibió un resultado para una tarea no registrada o ya unificada (ID: " + idTarea + "). Se ignora.");
            return;
        }

        resultadosParciales.get(idTarea).add(resultadoParcial);
        int restantes = contadoresSubtareas.get(idTarea).decrementAndGet();

        System.out.println("[ColaDeResultados] Resultado para Tarea " + idTarea + " encolado. Faltan " + restantes + ".");

        if (restantes == 0) {
            // ¡Llegaron todos! Procedemos a unificar.
            unificarResultadosDeTarea(idTarea);
        }
    }

    /**
     * Método privado que realiza el proceso de unificación final.
     * @param idTarea El ID de la tarea cuyos resultados se van a unificar.
     */
    private void unificarResultadosDeTarea(int idTarea) {
        System.out.println("[ColaDeResultados] Unificando resultados para Tarea " + idTarea + "...");
        
        Tarea tareaOriginal = tareasOriginales.get(idTarea);
        List<Resultado> listaDeResultados = resultadosParciales.get(idTarea);

        // Obtenemos la estrategia de la Factory para saber cómo unificar
        IEstrategiaDistribucion estrategia = DistribucionFactory.getEstrategia(tareaOriginal.getTipoOperacion());
        Resultado resultadoFinal = estrategia.unificar(listaDeResultados);
        
        // Creamos la tarea finalizada con el resultado completo
        tareaOriginal.setEstado("COMPLETADA");
        tareaOriginal.setResultado(resultadoFinal);

        // Actualizamos la tarea en la ColaDeTareas para que el cliente pueda consultarla
        ColaDeTareas.getInstancia().actualizarTarea(idTarea, tareaOriginal);
        System.out.println("[ColaDeResultados] Tarea " + idTarea + " unificada y actualizada con éxito.");

        // Limpiamos los mapas para liberar memoria
        contadoresSubtareas.remove(idTarea);
        resultadosParciales.remove(idTarea);
        tareasOriginales.remove(idTarea);
    }
}
