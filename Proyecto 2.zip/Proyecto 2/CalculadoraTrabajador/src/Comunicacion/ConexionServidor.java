/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Comunicacion;

import Common.Resultado;
import Common.Tarea;
import Common.XMLUtility;
import Domain.ProcesadorDeTareas;
import Domain.TareaComputacional;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;

/**
 *
 * @author kbren
 */
/**
 * Maneja la comunicación constante con el Servidor.
 */
public class ConexionServidor implements Runnable { //Maneja la comunicación constante con el Servidor.
    private final String hostServidor;
    private final int puertoServidor;
    private final ExecutorService poolDeHilos; // Recibe el pool de hilos

    public ConexionServidor(String host, int puerto, ExecutorService poolDeHilos) {
        this.hostServidor = host;
        this.puertoServidor = puerto;
        this.poolDeHilos = poolDeHilos;
    }

    @Override
    public void run() {
        try (Socket socket = new Socket(hostServidor, puertoServidor); 
// Usamos el protocolo robusto también
                 DataOutputStream out = new DataOutputStream(socket.getOutputStream()); 
                DataInputStream in = new DataInputStream(socket.getInputStream())) {

            System.out.println("COM: Conectado al servidor en " + hostServidor + ":" + puertoServidor);

            // 1. Enviar handshake
            String handshake = "<handshake><tipo>TRABAJADOR</tipo></handshake>";
            byte[] handshakeBytes = handshake.getBytes(StandardCharsets.UTF_8);
            out.writeInt(handshakeBytes.length);
            out.write(handshakeBytes);
            out.flush();

            // 2. Bucle para recibir tareas del servidor
            while (!Thread.currentThread().isInterrupted()) {
                // Leer longitud del mensaje
                int length = in.readInt();
                if (length > 0) {
                    byte[] tareaBytes = new byte[length];
                    in.readFully(tareaBytes, 0, length);
                    String xmlTareaRecibida = new String(tareaBytes, StandardCharsets.UTF_8);

                    System.out.println("COM: Tarea recibida del servidor.");
                    Tarea tarea = XMLUtility.fromXML(xmlTareaRecibida);

                    if (tarea != null) {
                        // Crea un objeto TareaComputacional que también necesita el DataOutputStream
                        // para poder responder.
                        TareaComputacional trabajo = new TareaComputacional(tarea, out);
                        poolDeHilos.submit(trabajo);
                    }
                }
            }
        } catch (EOFException e) {
            System.out.println("COM: El servidor cerró la conexión.");
        } catch (IOException e) {
            System.err.println("Error de conexión con el servidor: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Error inesperado en la conexión del trabajador: " + e.getMessage());
            e.printStackTrace();
        } finally {
            poolDeHilos.shutdown();
            System.out.println("COM: Conexión con el servidor terminada. Apagando hilos.");
        }
    }
//    public void run() {
//        try (
//            Socket socket = new Socket(hostServidor, puertoServidor);
//            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
//            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))
//        ) {
//            System.out.println("COM: Conectado al servidor en " + hostServidor + ":" + puertoServidor);
//            out.println("<handshake><tipo>TRABAJADOR</tipo></handshake>"); // Se presenta
//            
//            String xmlTareaRecibida;
//            while ((xmlTareaRecibida = in.readLine()) != null) {
//                System.out.println("COM: Tarea recibida del servidor.");
//                
//                Tarea tarea = XMLUtility.fromXML(xmlTareaRecibida);
//                if (tarea != null) {
//                    // En lugar de procesar la tarea aquí, la enviamos al pool de hilos.
//                    // El pool se encargará de asignarla a uno de los 8 hilos disponibles.
//                    TareaComputacional trabajo = new TareaComputacional(tarea, out);
//                    poolDeHilos.submit(trabajo);
//                }
//            }
//        } catch (Exception e) {
//            System.err.println("Error de conexion con el servidor: " + e.getMessage());
//        } finally {
//            poolDeHilos.shutdown(); // Cuando la conexión muere, apagar el pool
//            System.out.println("COM: Conexion con el servidor terminada. Apagando hilos.");
//        }
//    }
}