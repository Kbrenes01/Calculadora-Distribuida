/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import Common.Resultado;
import Common.Tarea;
import Common.TipoOperacion;
import static Common.TipoOperacion.BUSQUEDA_PRIMOS;
import static Common.TipoOperacion.DESCOMPOSICION_FACTORIAL;
import static Common.TipoOperacion.FACTORIAL;
import static Common.TipoOperacion.FIBONACCI;
import static Common.TipoOperacion.POTENCIA;
import static Common.TipoOperacion.PRODUCTO_MATRICES;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author kbren
 */
/**
 * Procesa una Tarea, valida sus parámetros, invoca a la CalculadoraReal 
 * y empaqueta el resultado. Actúa como capa de control antes del cálculo.
 */
public class ProcesadorDeTareas {

    /**
     * Punto de entrada para procesar una tarea. Valida, delega y empaqueta.
     * @param tarea La tarea a procesar.
     * @return Un objeto Resultado con el fruto del cálculo o un error.
     */
    public static Resultado procesar(Tarea tarea) {
        TipoOperacion tipo = tarea.getTipoOperacion();
        Map<String, String> params = tarea.getParametros();

        // Verificación inicial: Si no hay parámetros, no podemos hacer nada.
        if (params == null) {
            return new Resultado(false, "Error: La tarea recibida no contiene parámetros.", null);
        }
        
        try {
            switch (tipo) {
                case FACTORIAL: {
                    // 1. Validar que los parámetros necesarios existen.
                    if (!params.containsKey("rangoInicio") || !params.containsKey("rangoFin")) {
                        return new Resultado(false, "Error: Faltan parámetros 'rangoInicio' o 'rangoFin' para FACTORIAL.", null);
                    }
                    // 2. Parsear los parámetros.
                    long inicio = Long.parseLong(params.get("rangoInicio"));
                    long fin = Long.parseLong(params.get("rangoFin"));
                    // 3. Llamar a la calculadora real.
                    BigInteger resultadoParcial = CalculadoraReal.productoPorRango(inicio, fin);
                    return new Resultado(true, "Producto de rango calculado con éxito", resultadoParcial.toString());
                }

                case FIBONACCI: {
                    if (!params.containsKey("exponente")) {
                        return new Resultado(false, "Error: Falta el parámetro 'exponente' para FIBONACCI.", null);
                    }
                    int exponente = Integer.parseInt(params.get("exponente"));
                    Matriz2x2 matrizResultado = CalculadoraReal.calcularPotenciaDeMatrizFibonacci(exponente);
                    // Devolvemos la matriz serializada como un string para que el servidor la unifique.
                    String resultadoSerializado = String.join(",", 
                        matrizResultado.a.toString(), matrizResultado.b.toString(), 
                        matrizResultado.c.toString(), matrizResultado.d.toString());
                    return new Resultado(true, "Potencia de matriz Fibonacci calculada", resultadoSerializado);
                }

                case BUSQUEDA_PRIMOS: {
                    if (!params.containsKey("rangoInicio") || !params.containsKey("rangoFin")) {
                        return new Resultado(false, "Error: Faltan parámetros 'rangoInicio' o 'rangoFin' para BUSQUEDA_PRIMOS.", null);
                    }
                    long inicio = Long.parseLong(params.get("rangoInicio"));
                    long fin = Long.parseLong(params.get("rangoFin"));
                    List<Long> primos = CalculadoraReal.buscarPrimos(inicio, fin);
                    String datos = primos.stream().map(String::valueOf).collect(Collectors.joining(", "));
                    return new Resultado(true, "Primos encontrados en el rango", datos);
                }

                case POTENCIA: {
                    if (!params.containsKey("base") || !params.containsKey("exponente")) {
                        return new Resultado(false, "Error: Faltan parámetros 'base' o 'exponente' para POTENCIA.", null);
                    }
                    BigInteger base = new BigInteger(params.get("base"));
                    int exponente = Integer.parseInt(params.get("exponente"));
                    BigInteger resultado = CalculadoraReal.potencia(base, exponente);
                    return new Resultado(true, "Potencia calculada con éxito", resultado.toString());
                }

                case DESCOMPOSICION_FACTORIAL: {
                    if (!params.containsKey("numero") || !params.containsKey("inicioDivisor") || !params.containsKey("finDivisor")) {
                        return new Resultado(false, "Error: Faltan parámetros para DESCOMPOSICION_FACTORIAL.", null);
                    }
                    BigInteger numero = new BigInteger(params.get("numero"));
                    long inicioDivisor = Long.parseLong(params.get("inicioDivisor"));
                    long finDivisor = Long.parseLong(params.get("finDivisor"));
                    List<Long> factores = CalculadoraReal.factorizarPorRango(numero, inicioDivisor, finDivisor);
                    String resultado = factores.stream().map(String::valueOf).collect(Collectors.joining(", "));
                    return new Resultado(true, "Factores encontrados en el rango", resultado);
                }

                case PRODUCTO_MATRICES: {
                    if (!params.containsKey("matrizA") || !params.containsKey("matrizB")
                            || !params.containsKey("fila_inicio") || !params.containsKey("filas_a_calcular")) {
                        return new Resultado(false, "Error: Faltan parámetros para PRODUCTO_MATRICES.", null);
                    }

                    double[][] matrizA = CalculadoraReal.parsearMatriz(params.get("matrizA"));
                    double[][] matrizB = CalculadoraReal.parsearMatriz(params.get("matrizB"));
                    int filaInicio = Integer.parseInt(params.get("fila_inicio"));
                    int filasACalcular = Integer.parseInt(params.get("filas_a_calcular"));

                    double[][] resultadoParcial = CalculadoraReal.multiplicarPorcionMatriz(matrizA, matrizB, filaInicio, filasACalcular);

                    String resultadoParcialTexto = CalculadoraReal.matrizToString(resultadoParcial);

                    // Devolvemos el resultado con un prefijo para que el unificador sepa qué fila es.
                    String datosParaUnificador = filaInicio + "|" + resultadoParcialTexto;

                    return new Resultado(true, "Porción de matriz calculada.", datosParaUnificador);
                }

                default:
                    return new Resultado(false, "Operación no soportada por el trabajador: " + tipo, null);
            }

        } catch (NumberFormatException e) {
            // Este error ahora solo ocurrirá si el valor de un parámetro no es un número.
            e.printStackTrace();
            return new Resultado(false, "Error: El valor de un parámetro no es un número válido. " + e.getMessage(), null);
        } catch (Exception e) {
            // Captura cualquier otro error inesperado.
            e.printStackTrace();
            return new Resultado(false, "Error inesperado al procesar la tarea: " + e.getMessage(), null);
        }
    }
}