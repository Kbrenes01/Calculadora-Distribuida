/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kbren
 */
/**
 * Contiene la lógica matemática pura para realizar los cálculos pesados.
 * No se preocupa por la distribución ni la comunicación, solo por los números.
 * Usa BigInteger para manejar números de gran tamaño.
 */
public class CalculadoraReal {

    // --- FACTORIAL (Distribuido) ---
    /**
     * Calcula el producto de un rango de números. Usado para el factorial distribuido.
     * @param inicio El número inicial del rango.
     * @param fin El número final del rango.
     * @return El producto de todos los números desde inicio hasta fin como un BigInteger.
     */
    public static BigInteger productoPorRango(long inicio, long fin) {
        if (inicio == 0) inicio = 1; // 0! = 1, y multiplicar por 0 lo arruinaría.
        
        BigInteger resultadoParcial = BigInteger.ONE;
        for (long i = inicio; i <= fin; i++) {
            resultadoParcial = resultadoParcial.multiply(BigInteger.valueOf(i));
        }
        return resultadoParcial;
    }

    // --- FIBONACCI (Matricial) ---
    /**
     * Calcula la potencia de la matriz de Fibonacci.
     * @param exponente La potencia a la que se elevará la matriz.
     * @return El objeto Matriz2x2 resultado.
     */
    public static Matriz2x2 calcularPotenciaDeMatrizFibonacci(int exponente) {
        Matriz2x2 base = new Matriz2x2(); // Matriz de Fibonacci |1 1|, |1 0|
        Matriz2x2 resultado = new Matriz2x2(BigInteger.ONE, BigInteger.ZERO, BigInteger.ZERO, BigInteger.ONE); // Identidad
        
        while (exponente > 0) {
            if (exponente % 2 == 1) {
                resultado = resultado.multiplicar(base);
            }
            base = base.multiplicar(base);
            exponente /= 2;
        }
        return resultado;
    }
    
    // --- BÚSQUEDA DE PRIMOS ---
    /**
     * Busca todos los números primos dentro de un rango dado.
     * @param inicio Límite inferior del rango.
     * @param fin Límite superior del rango.
     * @return Una lista de números (Long) que son primos.
     */
    public static List<Long> buscarPrimos(long inicio, long fin) {
        List<Long> primosEncontrados = new ArrayList<>();
        for (long num = inicio; num <= fin; num++) {
            if (esPrimo(num)) {
                primosEncontrados.add(num);
            }
        }
        return primosEncontrados;
    }

    // --- POTENCIA ---
    /**
     * Calcula la potencia de un número base elevado a un exponente.
     * @param base El número base.
     * @param exponente El exponente.
     * @return El resultado como un BigInteger.
     */
    public static BigInteger potencia(BigInteger base, int exponente) {
        if (exponente < 0) {
            throw new IllegalArgumentException("El exponente no puede ser negativo.");
        }
        return base.pow(exponente);
    }

    // --- DESCOMPOSICIÓN FACTORIAL ---
    /**
 * Busca factores de un número grande dentro de un rango de posibles divisores,
 * asegurándose de que los factores encontrados sean primos.
 *
 * @param numeroAFactorizar El número a descomponer.
 * @param inicioDivisor El divisor inicial a probar.
 * @param finDivisor El divisor final a probar.
 * @return Una lista de factores PRIMOS (Long) encontrados en el rango.
 */
public static List<Long> factorizarPorRango(BigInteger numeroAFactorizar, long inicioDivisor, long finDivisor) {
    List<Long> factoresPrimosEncontrados = new ArrayList<>();

    // Iteramos sobre todos los números en el rango asignado.
    for (long i = inicioDivisor; i <= finDivisor; i++) {
        
        // Ignoramos el 0 y el 1, ya que no son factores primos.
        if (i <= 1) {
            continue;
        }

        // Primero, comprobamos si 'i' es un divisor. Esta es una operación rápida.
        if (numeroAFactorizar.mod(BigInteger.valueOf(i)).equals(BigInteger.ZERO)) {
            
            // SOLO SI 'i' es un divisor, invertimos tiempo en comprobar si también es primo.
            if (esPrimo(i)) {
                // Si cumple ambas condiciones, lo añadimos a la lista.
                factoresPrimosEncontrados.add(i);
            }
        }
    }
    return factoresPrimosEncontrados;
}

// TU MÉTODO esPrimo() se mantiene igual. Es correcto.
private static boolean esPrimo(long numero) {
    if (numero <= 1) return false;
    if (numero <= 3) return true;
    if (numero % 2 == 0 || numero % 3 == 0) return false;
    for (long j = 5; j * j <= numero; j = j + 6) {
        if (numero % j == 0 || numero % (j + 2) == 0) return false;
    }
    return true;
}

    // Métodos para PRODUCTO_MATRICES (esqueleto)
    // Método para convertir el string de la matriz a un arreglo 2D de doubles.
/**
 * Convierte un String a una matriz de doubles, validando estrictamente el formato.
 * Formato esperado:
 * - Filas separadas por saltos de línea (\n).
 * - Columnas separadas por comas (,).
 * - La matriz debe ser rectangular (todas las filas con igual número de columnas).
 * - Todos los valores deben ser números válidos.
 *
 * @param matrizTexto El String que representa la matriz.
 * @return Un arreglo 2D de doubles.
 * @throws IllegalArgumentException Si el formato del string es incorrecto.
 */
public static double[][] parsearMatriz(String matrizTexto) {
    // Validación 1: El texto no puede ser nulo o vacío.
    if (matrizTexto == null || matrizTexto.trim().isEmpty()) {
        throw new IllegalArgumentException("El texto de la matriz está vacío o es nulo.");
    }

    // Dividimos en filas, ignorando líneas en blanco que puedan haberse colado.
    String[] filas = matrizTexto.trim().split("\n");
    if (filas.length == 0) {
        throw new IllegalArgumentException("La matriz no contiene ninguna fila.");
    }

    // Validación 2: Determinamos el número de columnas esperado basándonos en la primera fila.
    String[] primeraFilaValores = filas[0].trim().split(",");
    int numColumnasEsperado = primeraFilaValores.length;
    if (numColumnasEsperado == 0) {
        throw new IllegalArgumentException("La primera fila de la matriz está vacía.");
    }

    // Creamos la matriz resultado
    double[][] matriz = new double[filas.length][numColumnasEsperado];

    // Iteramos sobre todas las filas para llenarla y validarla
    for (int i = 0; i < filas.length; i++) {
        String[] valores = filas[i].trim().split(",");
        
        // Validación 3: Todas las filas deben tener el mismo número de columnas.
        if (valores.length != numColumnasEsperado) {
            throw new IllegalArgumentException(
                "La matriz no es rectangular. La fila 0 tiene " + numColumnasEsperado + 
                " columnas, pero la fila " + i + " tiene " + valores.length + " columnas."
            );
        }

        // Iteramos sobre las columnas de la fila actual
        for (int j = 0; j < valores.length; j++) {
            try {
                // Validación 4: Cada valor debe ser un número parseable.
                matriz[i][j] = Double.parseDouble(valores[j].trim());
            } catch (NumberFormatException e) {
                // Si falla, lanzamos una excepción con un mensaje muy específico.
                throw new IllegalArgumentException(
                    "Valor no numérico encontrado en la matriz en la posición [fila=" + i + ", columna=" + j + "]. " +
                    "El valor problemático es: '" + valores[j] + "'"
                );
            }
        }
    }
    
    return matriz;
}

// Método que calcula solo las filas asignadas de la matriz resultado.
public static double[][] multiplicarPorcionMatriz(double[][] a, double[][] b, int filaInicio, int filasACalcular) {
    int filasA = a.length;
    int colsA = a[0].length;
    int colsB = b[0].length;

    if (colsA != b.length) {
        throw new IllegalArgumentException("Las dimensiones de las matrices no son compatibles para la multiplicación.");
    }
    
    double[][] resultadoParcial = new double[filasACalcular][colsB];
    
    for (int i = 0; i < filasACalcular; i++) {
        for (int j = 0; j < colsB; j++) {
            for (int k = 0; k < colsA; k++) {
                resultadoParcial[i][j] += a[filaInicio + i][k] * b[k][j];
            }
        }
    }
    return resultadoParcial;
}

// Método para convertir la porción de matriz resultado a un String.
public static String matrizToString(double[][] matriz) {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < matriz.length; i++) {
        for (int j = 0; j < matriz[i].length; j++) {
            sb.append(matriz[i][j]).append(j == matriz[i].length - 1 ? "" : ",");
        }
        sb.append("\n");
    }
    return sb.toString().trim();
}
}
