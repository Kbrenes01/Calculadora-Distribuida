/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

import Common.Resultado;
import Common.Tarea;
import Common.XMLUtility;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
/**
 *
 * @author kbren
 */

/**
 * Representa una unidad de trabajo que puede ser ejecutada por un hilo del pool.
 * Calcula el resultado de una tarea y se encarga de enviarlo de vuelta al servidor.
 */
public class TareaComputacional implements Runnable { //Representa una unidad de trabajo que puede ser ejecutada por un hilo del pool. 
    //Calcula el resultado de una tarea y se encarga de enviarlo de vuelta al servidor.
    private final Tarea tareaAProcesar;
//    private final PrintWriter outAlServidor; // Canal de comunicación para responder
    private final DataOutputStream outAlServidor; // Cambiamos PrintWriter por DataOutputStream

    public TareaComputacional(Tarea tarea, DataOutputStream out) {
        this.tareaAProcesar = tarea;
        this.outAlServidor = out;
    }

    @Override
    public void run() {
        Resultado resultado = ProcesadorDeTareas.procesar(tareaAProcesar);
        tareaAProcesar.setResultado(resultado);
        tareaAProcesar.setEstado("COMPLETADA_POR_TRABAJADOR");
        
        synchronized (outAlServidor) {
            try {
                String xmlRespuesta = XMLUtility.toXML(tareaAProcesar);
                byte[] respuestaBytes = xmlRespuesta.getBytes(StandardCharsets.UTF_8);
                
                outAlServidor.writeInt(respuestaBytes.length); // Enviar longitud
                outAlServidor.write(respuestaBytes);           // Enviar datos
                outAlServidor.flush();
                
                System.out.println(" [Hilo " + Thread.currentThread().getId() + "] Enviando resultado al servidor.");
            } catch (IOException e) {
                System.err.println("Error al enviar resultado al servidor: " + e.getMessage());
            }
        }
        
        
//        System.out.println("   [Hilo " + Thread.currentThread().getId() + "] Inicia procesamiento de tarea ID: " + tareaAProcesar.getIdCliente());
//        Resultado resultado = ProcesadorDeTareas.procesar(tareaAProcesar); // Procesa la tarea para obtener el resultado
//
//        tareaAProcesar.setResultado(resultado); //Empaquetar el resultado en la tarea original
//        tareaAProcesar.setEstado("COMPLETADA_POR_TRABAJADOR");
//
//        System.out.println("Resultado calculado por el trabajador:");
//        System.out.println("Éxito: " + resultado.isExito());
//        System.out.println("Mensaje: " + resultado.getMensaje());
//        System.out.println("Datos: " + resultado.getDatos());
//
//        synchronized (outAlServidor) { // Sincronizar el envío para evitar que múltiples hilos escriban a la vez
//            String xmlRespuesta = XMLUtility.toXML(tareaAProcesar);
//            System.out.println("   [Hilo " + Thread.currentThread().getId() + "] Enviando resultado al servidor.");
//            outAlServidor.println(xmlRespuesta);
//        }
    }
}