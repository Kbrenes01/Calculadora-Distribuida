/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadoratrabajador;

import Common.Resultado;
import Common.Tarea;
import Common.XMLUtility;
import Comunicacion.ConexionServidor;
import Domain.ProcesadorDeTareas;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author kbren
 */
public class CalculadoraTrabajador {

   // --- Configuración ---
    private static final String HOST_SERVIDOR = "10.54.236.128";
    private static final int PUERTO_SERVIDOR = 9090;
    private static final int NUMERO_DE_HILOS = 8; // La capacidad del trabajador

    public static void main(String[] args) {
        System.out.println("-> Iniciando CalculadoraTrabajador con capacidad para " + NUMERO_DE_HILOS + " hilos.");

        // 1. Crear un pool de hilos con un tamaño fijo (nuestros 8 hilos).
        // Este pool gestionará la ejecución concurrente de tareas.
        ExecutorService poolDeHilos = Executors.newFixedThreadPool(NUMERO_DE_HILOS);

        // 2. Crear el objeto de conexión y pasarle el pool de hilos.
        ConexionServidor conexion = new ConexionServidor(HOST_SERVIDOR, PUERTO_SERVIDOR, poolDeHilos);
        
        // 3. Iniciar la conexión en su propio hilo.
        // Este hilo principal solo se encarga de escuchar al servidor.
        new Thread(conexion).start();
        
        System.out.println("Trabajador listo y esperando tareas del servidor...");
    }
}
